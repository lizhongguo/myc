
#include <assert.h>
#include <stdio.h>
#include <iostream>
#include "MyExprLexer.hpp"
#include "MyExprParser.hpp"


void indent(int indent_level)
{
  if (indent_level > 0) {
    const size_t BUFSIZE = 127;
    char buf[ BUFSIZE+1 ];
    int i;
    
    for (i = 0; i < indent_level && i < BUFSIZE; i++) {
      buf[i] = ' ';
    }
    buf[i] = '\0';
    printf("%s", buf );
  }
} // pr_indent


void trav_tree( RefAST top, int ind )
{
  if (top != NULL) {
    std::string str;
    indent( ind );

    str = top->getText();
    std::cout << str << "\n";
    if (top->getFirstChild() != NULL) {
      printf("kid: ");
      trav_tree( top->getFirstChild(), ind+2 );
    }
    if (top->getNextSibling()) {
      printf("sib: ");
      trav_tree( top->getNextSibling(), ind );
    }
  }
}



int main()
{
	try {
		MyExprLexer lexer(std::cin);
		MyExprParser parser(lexer);
		parser.exprlist();

		if (parser.getAST() != NULL) {
		  printf("tree traverse:\n");
		  trav_tree( parser.getAST(), 0 );
		}

	} catch(std::exception& e) {
		std::cerr << "exception: " << e.what() << std::endl;
	}
	return 0;
}
